package com.example.platformer

interface IGameInterface {

    fun onGameOver()
    fun onGameWin()

}