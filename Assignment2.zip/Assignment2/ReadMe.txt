Game Development in Android-Assginment2-Platform-Yin Liang

Implementation
2.Static enemy
  -deal damage to the player
  -in the following 50 frames after the player got damaged, the player is invincible.
  -play sound when collided
3.Dynamic coin
  -moves back and forth
  -collectible
  -physics which inherint from the dynamic entity class.
  -play sound when collided
4.HUD
  -health
  -coins colected&coins needed to win
5.level layout read from file
6.Audio added
  -BGM
  -collisions
  -start
  -die